package prototipo_grupo4;

public class NodoEvento {

    Evento evento;
    NodoEvento siguiente;

    public NodoEvento(Evento evento) {
        this.evento = evento;
        this.siguiente = null;
    }
}
