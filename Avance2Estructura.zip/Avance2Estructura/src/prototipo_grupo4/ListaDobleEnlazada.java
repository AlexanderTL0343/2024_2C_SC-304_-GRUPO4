package prototipo_grupo4;

public class ListaDobleEnlazada {

    private Nodo cabeza;
    private Nodo cola;

    public ListaDobleEnlazada() {
        this.cabeza = null;
        this.cola = null;
    }
    //metodos para la lista doble enlazada para participantes 
    public void agregar(Participante participante) {
        Nodo nuevoNodo = new Nodo(participante);
        if (cabeza == null) {
            cabeza = nuevoNodo;
            cola = nuevoNodo;
        } else {
            cola.siguiente = nuevoNodo;
            nuevoNodo.anterior = cola;
            cola = nuevoNodo;
        }
    }

    public Nodo buscar(String nombre) {
        Nodo actual = cabeza;
        while (actual != null) {
            if (actual.participante.getNombre().equals(nombre)) {
                return actual;
            }
            actual = actual.siguiente;
        }
        return null;
    }

    public void editar(String nombre, Participante nuevoParticipante) {
        Nodo nodoAEditar = buscar(nombre);
        if (nodoAEditar != null) {
            nodoAEditar.participante = nuevoParticipante;
        }
    }

    public void eliminar(String nombre) {
        Nodo actual = cabeza;

        while (actual != null) {
            if (actual.participante.getNombre().equals(nombre)) {
                if (actual.anterior != null) {
                    actual.anterior.siguiente = actual.siguiente;
                } else {
                    cabeza = actual.siguiente; // El nodo a eliminar es la cabeza
                }

                if (actual.siguiente != null) {
                    actual.siguiente.anterior = actual.anterior;
                } else {
                    cola = actual.anterior; // El nodo a eliminar es la cola
                }

                // Nodo eliminado
                return;
            }
            actual = actual.siguiente;
        }
    }

    public void imprimirLista() {
        Nodo actual = cabeza;
        while (actual != null) {
            System.out.println(actual.participante.getNombre());
            actual = actual.siguiente;
        }
    }
}
