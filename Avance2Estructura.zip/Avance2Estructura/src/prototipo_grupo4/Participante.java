package prototipo_grupo4;

public class Participante {

    private String nombre;
    private String equipo;
    private int edad;
    private String evento;

    public Participante(String nombre, String equipo, int edad, String evento) {
        this.nombre = nombre;
        this.equipo = equipo;
        this.edad = edad;
        this.evento = evento;
    }

    public String getEvento() {
        return evento;
    }

    public void setEvento(String evento) {
        this.evento = evento;
    }

    public String getEquipo() {
        return equipo;
    }

    public void setEquipo(String equipo) {
        this.equipo = equipo;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public Participante(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
