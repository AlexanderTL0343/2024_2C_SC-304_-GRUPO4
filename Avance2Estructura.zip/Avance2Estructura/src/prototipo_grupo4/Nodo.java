package prototipo_grupo4;

public class Nodo {
    //esta clase seria para la lista de participante/doble enlazada
    Participante participante;
    Nodo siguiente;
    Nodo anterior;

    public Nodo(Participante participante) {
        this.participante = participante;
        this.siguiente = null;
        this.anterior = null;
    }
}
