package prototipo_grupo4;

public class Evento {

    private String nombre;
    private String fecha; // Almacenamos la fecha como String
    private String ubicacion;
    private ListaDobleEnlazada participantes;

    public Evento(String nombre, String fecha, String ubicacion) {
        this.nombre = nombre;
        this.fecha = fecha;
        this.ubicacion = ubicacion;
        this.participantes = new ListaDobleEnlazada();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public ListaDobleEnlazada getParticipantes() {
        return participantes;
    }

    //metodo para agregar un participante
    public void agregarParticipante(Participante participante) {
        participantes.agregar(participante);
    }
}
