package prototipo_grupo4;

import java.io.FileWriter;
import java.io.IOException;

public class ArbolClasificacion {

    private NodoEquipo raiz;

    public ArbolClasificacion() {
        this.raiz = null;
    }

    //metodo para insertar un nuevo equipo en el arbol
    public void insertar(String nombreEquipo, int victorias) {
        raiz = insertarRecursivo(raiz, nombreEquipo, victorias);
    }

    private NodoEquipo insertarRecursivo(NodoEquipo nodo, String nombreEquipo, int victorias) {
        if (nodo == null) {
            return new NodoEquipo(nombreEquipo, victorias);
        }

        if (victorias < nodo.victorias) {
            nodo.izquierda = insertarRecursivo(nodo.izquierda, nombreEquipo, victorias);
        } else if (victorias > nodo.victorias) {
            nodo.derecha = insertarRecursivo(nodo.derecha, nombreEquipo, victorias);
        } else {
            // Si tienen el mismo número de victorias, podríamos decidir el orden alfabético
            if (nombreEquipo.compareTo(nodo.nombreEquipo) < 0) {
                nodo.izquierda = insertarRecursivo(nodo.izquierda, nombreEquipo, victorias);
            } else {
                nodo.derecha = insertarRecursivo(nodo.derecha, nombreEquipo, victorias);
            }
        }

        return nodo;
    }

    //metodo para imprimir el arbol en orden
    public void imprimirEnOrden() {
        imprimirEnOrdenRecursivo(raiz);
    }

    private void imprimirEnOrdenRecursivo(NodoEquipo nodo) {
        if (nodo != null) {
            imprimirEnOrdenRecursivo(nodo.izquierda);
            System.out.println(nodo.nombreEquipo + " - " + nodo.victorias + " victorias");
            imprimirEnOrdenRecursivo(nodo.derecha);
        }
    }

    //metodo para guardar el arbol de en un archivo TXT
    public void guardarEnArchivo(String nombreArchivo) {
        try (FileWriter writer = new FileWriter(nombreArchivo)) {
            guardarEnArchivoRecursivo(raiz, writer);
            System.out.println("Árbol de clasificación guardado en " + nombreArchivo);
        } catch (IOException e) {
            System.out.println("Ocurrió un error al guardar el árbol de clasificación: " + e.getMessage());
        }
    }

    private void guardarEnArchivoRecursivo(NodoEquipo nodo, FileWriter writer) throws IOException {
        if (nodo != null) {
            guardarEnArchivoRecursivo(nodo.izquierda, writer);
            writer.write(nodo.nombreEquipo + " - " + nodo.victorias + " victorias\n");
            guardarEnArchivoRecursivo(nodo.derecha, writer);
        }
    }
}
