package prototipo_grupo4;

import java.io.FileWriter;
import java.io.IOException;

public class ListaDobleEnlazada {

    private Nodo cabeza;
    private Nodo cola;

    public ListaDobleEnlazada() {
        this.cabeza = null;
        this.cola = null;
    }

    public Nodo getCabeza() {
        return cabeza;
    }

    public void agregar(Participante participante) {
        Nodo nuevoNodo = new Nodo(participante);
        if (cabeza == null) {
            cabeza = nuevoNodo;
            cola = nuevoNodo;
        } else {
            cola.siguiente = nuevoNodo;
            nuevoNodo.anterior = cola;
            cola = nuevoNodo;
        }
    }

    public Nodo buscar(String nombre) {
        Nodo actual = cabeza;
        while (actual != null) {
            if (actual.participante.getNombre().equals(nombre)) {
                return actual;
            }
            actual = actual.siguiente;
        }
        return null;
    }

    public void editar(String nombre, Participante nuevoParticipante) {
        Nodo nodoAEditar = buscar(nombre);
        if (nodoAEditar != null) {
            nodoAEditar.participante = nuevoParticipante;
        }
    }

    public void eliminar(String nombre) {
        Nodo actual = cabeza;

        while (actual != null) {
            if (actual.participante.getNombre().equals(nombre)) {
                if (actual.anterior != null) {
                    actual.anterior.siguiente = actual.siguiente;
                } else {
                    cabeza = actual.siguiente; // El nodo a eliminar es la cabeza
                }

                if (actual.siguiente != null) {
                    actual.siguiente.anterior = actual.anterior;
                } else {
                    cola = actual.anterior; // El nodo a eliminar es la cola
                }

                // Nodo eliminado
                return;
            }
            actual = actual.siguiente;
        }
    }

    public void imprimirLista() {
        Nodo actual = cabeza;
        while (actual != null) {
            System.out.println(actual.participante.getNombre());
            actual = actual.siguiente;
        }
    }
    // Método para guardar la lista de participantes en un archivo TXT
    public void guardarEnArchivo(String nombreArchivo) {
        try (FileWriter writer = new FileWriter(nombreArchivo)) {
            Nodo actual = cabeza;
            while (actual != null) {
                // Escribe cada participante en una línea del archivo
                writer.write(actual.participante.getNombre() + "\n");
                actual = actual.siguiente;
            }
            System.out.println("Lista de participantes guardada en " + nombreArchivo);
        } catch (IOException e) {
            System.out.println("Ocurrió un error al guardar la lista de participantes: " + e.getMessage());
        }
    }
}
