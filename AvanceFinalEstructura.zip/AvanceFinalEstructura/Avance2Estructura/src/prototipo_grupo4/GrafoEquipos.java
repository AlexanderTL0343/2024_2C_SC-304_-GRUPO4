package prototipo_grupo4;

import java.io.FileWriter;
import java.io.IOException;

public class GrafoEquipos {

    NodoGrafoEquipo[] equipos;
    int numEquipos;

    public GrafoEquipos(int maxEquipos) {
        this.equipos = new NodoGrafoEquipo[maxEquipos];
        this.numEquipos = 0;
    }

    // Método para agregar un equipo al grafo
    public void agregarEquipo(String nombreEquipo, int maxVecinos) {
        if (numEquipos < equipos.length) {
            equipos[numEquipos++] = new NodoGrafoEquipo(nombreEquipo, maxVecinos);
        } else {
            System.out.println("No se pueden agregar más equipos al grafo");
        }
    }

    // Método para encontrar un equipo por su nombre
    public NodoGrafoEquipo encontrarEquipo(String nombreEquipo) {
        for (int i = 0; i < numEquipos; i++) {
            if (equipos[i].nombreEquipo.equals(nombreEquipo)) {
                return equipos[i];
            }
        }
        return null;
    }

    // Método para agregar una arista entre dos equipos
    public void agregarPartido(String equipo1, String equipo2) {
        NodoGrafoEquipo nodo1 = encontrarEquipo(equipo1);
        NodoGrafoEquipo nodo2 = encontrarEquipo(equipo2);

        if (nodo1 != null && nodo2 != null) {
            nodo1.agregarVecino(nodo2);
            nodo2.agregarVecino(nodo1);
        } else {
            System.out.println("Uno o ambos equipos no existen");
        }
    }

    // Método para imprimir los equipos y sus vecinos
    public void imprimirGrafo() {
        for (int i = 0; i < numEquipos; i++) {
            NodoGrafoEquipo equipo = equipos[i];
            System.out.print(equipo + " -> ");
            for (int j = 0; j < equipo.numVecinos; j++) {
                System.out.print(equipo.vecinos[j] + " ");
            }
            System.out.println();
        }
    }

    // Método para guardar el grafo de equipos en un archivo TXT
    public void guardarEnArchivo(String nombreArchivo) {
        try (FileWriter writer = new FileWriter(nombreArchivo)) {
            for (int i = 0; i < numEquipos; i++) {
                NodoGrafoEquipo equipo = equipos[i];
                writer.write(equipo.nombreEquipo + " -> ");
                for (int j = 0; j < equipo.numVecinos; j++) {
                    writer.write(equipo.vecinos[j].nombreEquipo + " ");
                }
                writer.write("\n");
            }
            System.out.println("Grafo de equipos guardado en " + nombreArchivo);
        } catch (IOException e) {
            System.out.println("Ocurrió un error al guardar el grafo de equipos: " + e.getMessage());
        }
    }
}
