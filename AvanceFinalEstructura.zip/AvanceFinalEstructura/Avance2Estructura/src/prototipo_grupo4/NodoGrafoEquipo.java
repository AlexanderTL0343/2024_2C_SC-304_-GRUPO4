/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prototipo_grupo4;

/**
 *
 * @author alext
 */
public class NodoGrafoEquipo {
    String nombreEquipo;
    NodoGrafoEquipo[] vecinos;
    int numVecinos;

    public NodoGrafoEquipo(String nombreEquipo, int maxVecinos) {
        this.nombreEquipo = nombreEquipo;
        this.vecinos = new NodoGrafoEquipo[maxVecinos];
        this.numVecinos = 0;
    }

    public void agregarVecino(NodoGrafoEquipo equipo) {
        if (numVecinos < vecinos.length) {
            vecinos[numVecinos++] = equipo;
        } else {
            System.out.println("No se pueden agregar más vecinos al equipo " + nombreEquipo);
        }
    }

    @Override
    public String toString() {
        return nombreEquipo;
    }
}
