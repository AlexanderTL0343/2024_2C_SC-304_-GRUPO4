/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prototipo_grupo4;

/**
 *
 * @author alext
 */
public class NodoEquipo {

    String nombreEquipo;
    int victorias;
    NodoEquipo izquierda;
    NodoEquipo derecha;

    public NodoEquipo(String nombreEquipo, int victorias) {
        this.nombreEquipo = nombreEquipo;
        this.victorias = victorias;
        this.izquierda = null;
        this.derecha = null;
    }
}
