package prototipo_grupo4;

import java.io.FileWriter;
import java.io.IOException;

public class ListaEnlazadaSimple {

    private NodoEvento cabeza;

    public ListaEnlazadaSimple() {
        this.cabeza = null;
    }

    public void agregar(Evento evento) {
        NodoEvento nuevoNodo = new NodoEvento(evento);
        if (cabeza == null) {
            cabeza = nuevoNodo;
        } else {
            NodoEvento actual = cabeza;
            while (actual.siguiente != null) {
                actual = actual.siguiente;
            }
            actual.siguiente = nuevoNodo;
        }
    }

    public Evento buscar(String nombre) {
        NodoEvento actual = cabeza;
        while (actual != null) {
            if (actual.evento.getNombre().equals(nombre)) {
                return actual.evento;
            }
            actual = actual.siguiente;
        }
        return null;
    }

    public void eliminar(String nombre) {
        if (cabeza == null) {
            return;
        }

        if (cabeza.evento.getNombre().equals(nombre)) {
            cabeza = cabeza.siguiente;
            return;
        }

        NodoEvento actual = cabeza;
        while (actual.siguiente != null) {
            if (actual.siguiente.evento.getNombre().equals(nombre)) {
                actual.siguiente = actual.siguiente.siguiente;
                return;
            }
            actual = actual.siguiente;
        }
    }

    public void imprimirEventos() {
        NodoEvento actual = cabeza;
        while (actual != null) {
            System.out.println(actual.evento.getNombre() + " - " + actual.evento.getFecha() + " - " + actual.evento.getUbicacion());
            actual = actual.siguiente;
        }
    }

    public void editar(String nombre, String nuevaFecha, String nuevaUbicacion) {
        Evento evento = buscar(nombre);
        if (evento != null) {
            evento.setFecha(nuevaFecha);
            evento.setUbicacion(nuevaUbicacion);
        }
    }

    // Método para guardar la lista de eventos en un archivo TXT
    public void guardarEnArchivo(String nombreArchivo) {
        try (FileWriter writer = new FileWriter(nombreArchivo)) {
            NodoEvento actual = cabeza;
            while (actual != null) {
                // Escribe cada evento en una línea del archivo
                writer.write(actual.evento.getNombre() + "," + actual.evento.getFecha() + "," + actual.evento.getUbicacion() + "\n");
                actual = actual.siguiente;
            }
            System.out.println("Lista guardada en " + nombreArchivo);
        } catch (IOException e) {
            System.out.println("Ocurrió un error al guardar la lista: " + e.getMessage());
        }
    }
}
