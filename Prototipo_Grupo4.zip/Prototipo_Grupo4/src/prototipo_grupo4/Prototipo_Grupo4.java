package prototipo_grupo4;

import frame.index;

public class Prototipo_Grupo4 {

    public static void main(String[] args) {
        // lo que se hace el llamdo al index para que sea  visible 
        index index = new index();
        index.setVisible(true);
    }

}
